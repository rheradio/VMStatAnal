#!/bin/bash
sudo mkdir /usr/local/bin
sudo cp probabitiy histogram /usr/local/bin
