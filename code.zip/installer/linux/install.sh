#!/bin/bash
sudo cp probability histogram /usr/local/bin
