#!/bin/bash
sudo rm /usr/local/bin/probability /usr/local/bin/histogram
